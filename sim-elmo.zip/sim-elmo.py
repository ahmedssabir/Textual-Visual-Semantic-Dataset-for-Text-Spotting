import embeddings
import numpy as np
import argparse
import sys
import tensorflow as tf

from sklearn.metrics.pairwise import cosine_similarity

def cos_sim(a, b):
    return np.inner(a, b) / (np.linalg.norm(a) * (np.linalg.norm(b)))


file1 = []

file2 = []

  
with open('caption1.txt','rU') as f:     
    for line in f:

       file1.append(line.rstrip())


with open('caption2.txt','rU') as f1:    
    
    for line1 in f1:

       file2.append(line1.rstrip())
       #break

resutl=[]



f=open('ELMO-sim.txt', "w")
for i in range(len(file1)):
    temp =[]
    messages  = file1[i]
    messages1 = file2[i]
    #messages  = "people read the book"
    #messages1 = "man in the street eating hotdog"
  
    tf.logging.set_verbosity(tf.logging.ERROR)
    

    def cos_sim(a, b):
        return np.inner(a, b) / (np.linalg.norm(a) * (np.linalg.norm(b)))

    results_elmo, results_nnlm = embeddings.get_embeddings_elmo_nnlm([messages , messages1])


    w =  cos_sim(results_elmo[0], results_elmo[1])
    tf.reset_default_graph()
  

    
    temp.append(w)

    result= file1[i]+','+file2[i]+','+str(w)

    f.write(result)
    #f.write(result)
    f.write('\n')
    print(result)
    #del result
    #close.sess()
    
f.close()





