# ELMo: 0.83875865, NNLM: 1.0
python comparison_test.py "people read the book" "the book people read"

# ELMo: 0.57716763, NNLM: 0.7459192
python comparison_test.py "The bank on the other end of the street was robbed" "We had a picnic on the bank of the river"
